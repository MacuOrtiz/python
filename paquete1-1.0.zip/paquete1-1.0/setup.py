from setuptools import setup

setup(name="paquete1", version="1.0", description="Entrega 1 curso de Python", 
author="Maria Ortiz", author_email="macuortiz.c@gmail.com")