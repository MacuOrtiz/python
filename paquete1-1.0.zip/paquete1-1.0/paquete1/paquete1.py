class Usuario:
    def __init__(self, usuario, correo):
        self.usuario = usuario
        self.correo = correo
    


    def __str__(self):
     return f"Su ururio {self.usuario} y y correo es {self.correo} "